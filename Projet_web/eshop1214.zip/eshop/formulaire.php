<!DOCTYPE html>
<html>

<form action="localhost:8787/identification.php" method="GET">
        Login
        <input type="text" class="email" name="email" placeholder="email"/>
        Password
        <input type="motDePasse" id="mdp" class="motDePasse" name="motDePasse" onkeypress="return runScript(event)"  placeholder="password"/>
        <input type="submit" id="valider" class="validez" value="validez" />
        <script>
          document.getElementById("mdp")
          .addEventListener("keyup", function(event){
             event.preventDefault();
             if(event.keyCode === 13){
                document.getElementById("valider").click();
             }
          });
          </script>

</html>


