CREATE TABLE IF NOT EXISTS produits (
  idProduit int NOT NULL PRIMARY KEY AUTO_INCREMENT,
  catégorie enum('téléphone', 'tablette', 'écouteurs'),
  nom varchar(50) NOT NULL,
  descriptif varchar(60),
  marque varchar(50) NOT NULL,
  prix float,
  stock int)
ENGINE=InnoDB CHARACTER SET utf8 COLLATE utf8_general_ci;


INSERT INTO produits (catégorie, nom, marque, prix, descriptif) VALUES
('téléphone', 'Galaxy A20', 'Samsung', 155, 'Pas très cher mais bug beaucoup'),
('téléphone', 'Galaxy S10E', 'Samsung', 499.99, 'Il est vert'),
('téléphone', 'iPhone X', 'Apple', 729, 'Cher pour peu'),
('tablette', 'Oxygen', 'Archos', 169, 'Ceci est une tablette'),
('tablette', 'iPad Air 2', 'Apple', 199, ''),
('écouteurs', 'airPods 2', 'Apple', 179, 'cher pour peu');

CREATE TABLE IF NOT EXISTS clients (
  email varchar(32) NOT NULL PRIMARY KEY,
  motDePasse varchar(16) NOT NULL,
  nom varchar (16) NOT NULL,
  prenom varchar (16) NOT NULL,
  adresse varchar (50) NOT NULL,
  telephone varchar (15) NOT NULL)
ENGINE=InnoDB CHARACTER SET utf8 COLLATE utf8_general_ci;


CREATE TABLE IF NOT EXISTS commandes(
    idCommande int NOT NULL PRIMARY KEY AUTO_INCREMENT,
    dateCommande date,
    etat varchar(30),
    email varchar (32))
ENGINE=InnoDB CHARACTER SET utf8 COLLATE utf8_general_ci;


CREATE TABLE IF NOT EXISTS lignesCommandes(
    idLigneCommande int NOT NULL PRIMARY KEY AUTO_INCREMENT,
    idCommande int, 
    quantite int,
    montant float,
    idProduit int)
ENGINE=InnoDB CHARACTER SET utf8 COLLATE utf8_general_ci;

--ALTER TABLE commandes ADD FOREIGN KEY(email) REFERENCES clients (email) ;
--ALTER TABLE lignescommandes ADD FOREIGN KEY (idCommande) REFERENCES commandes(idCommande);
--ALTER TABLE lignescommandes ADD FOREIGN KEY (idProduit) REFERENCES produits(idProduit);