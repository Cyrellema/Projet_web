<html>
  <head>
    <title> Liste des produits </title>
    <link rel="stylesheet" href="formulaire.css" />
   <link rel="stylesheet" href="nav.css">
  </head>
  <body>
    <h3> Liste des produits </h3>
    <table align=center border="1" cellspacing="0" width="100%">
        <tr>
            <td >ID</td>
            <td>CATEGORIE</td>
            <td>NOM</td>
            <td>DESCRIPTIF</td>
            <td>MARQUE</td>
            <td>PRIX</td>
            <td>STOCK</td>
            <td>...</td>
        </tr>
<?php
   /*connect with database*/
    $conn = mysqli_connect("localhost","root","","projet_web");
    if(empty($conn)){
        die("mysqli_connect failed:".mysqli_connect_error());
    }
    mysqli_query($conn,"SET NAMES UTF8");
    $sql = "SELECT * FROM produits";
    $results = $conn->query($sql);
    while($row = $results->fetch_row()){
        /*print($row[0] . " " . $row[1] . " " . $row[2] . " " . $row[3] . " " . $row[4] . " " . $row[5] . " " . $row[6] . "<BR>");
        show results in table↓*/
        $exist = true; 
    ?>
     <tr>
        <td><?PHP echo($row[0]); ?></td>
        <td><?PHP echo($row[1]); ?></td>
        <td><?PHP echo($row[2]); ?></td>
        <td><?PHP echo($row[3]); ?></td>
        <td><?PHP echo($row[4]); ?></td>
        <td><?PHP echo($row[5]); ?></td>
        <td><?PHP echo($row[6]); ?></td>
        <td><a href="#">AJOUTER PANNIER</a>
    </tr>
    <?php
    }
    if (! $exist)
    {
      print"no contents";
    }
    ?>


 </body>
</html>